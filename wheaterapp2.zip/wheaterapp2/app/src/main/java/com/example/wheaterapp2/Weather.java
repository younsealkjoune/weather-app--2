package com.example.wheaterapp2;

public class Weather {
    public String description;
}
