package com.example.wheaterapp2;
import com.example.wheaterapp2.WeatherApiService;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private EditText cityInput;
    private TextView weatherResult;
    private final String API_KEY = "b83f09652bca3006903f15be9cb4bbf0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityInput = findViewById(R.id.cityInput);
        Button fetchButton = findViewById(R.id.fetchButton);
        weatherResult = findViewById(R.id.weatherResult);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherApiService apiService = retrofit.create(WeatherApiService.class);

        fetchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String city = cityInput.getText().toString().trim();
                if (!city.isEmpty()) {
                    Call<WeatherResponse> call = apiService.getCurrentWeather(city, API_KEY, "metric");
                    call.enqueue(new Callback<WeatherResponse>() {
                        @Override
                        public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                            if (response.isSuccessful()) {
                                WeatherResponse data = response.body();
                                String result = data.name + ": " + data.main.temp + "°C, " + data.weather.get(0).description;
                                weatherResult.setText(result);
                            } else {
                                weatherResult.setText("City not found.");
                            }
                        }

                        @Override
                        public void onFailure(Call<WeatherResponse> call, Throwable t) {
                            weatherResult.setText("Error: " + t.getMessage());
                        }
                    });
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a city", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
