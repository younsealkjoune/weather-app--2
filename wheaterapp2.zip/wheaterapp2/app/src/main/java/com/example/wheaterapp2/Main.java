package com.example.wheaterapp2;

public class Main {
    public float temp;
}
